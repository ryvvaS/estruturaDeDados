#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definir a estrutura para um artista
typedef struct {
    char nome[50];
    char genero[50];
    char local[50];
    int albums;
} Artista;

// Função de comparação para qsort
int compararArtistas(const void *a, const void *b) {
    return strcmp(((Artista *)a)->nome, ((Artista *)b)->nome);
}

// Função para ler os artistas do arquivo e armazená-los em uma lista dinâmica
int lerArtistas(Artista **lista) {
    FILE *arquivo;
    arquivo = fopen("artistas.txt", "r");
    
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo artistas.txt.\n");
        return 0;
    }

    int numArtistas;
    fscanf(arquivo, "%d\n", &numArtistas);

    *lista = (Artista *)malloc(numArtistas * sizeof(Artista));

    for (int i = 0; i < numArtistas; i++) {
        fscanf(arquivo, "%s %s %s %d\n", (*lista)[i].nome, (*lista)[i].genero, (*lista)[i].local, &(*lista)[i].albums);
    }

    // Após ler os artistas, ordene a lista por nome
    qsort(*lista, numArtistas, sizeof(Artista), compararArtistas);

    fclose(arquivo);
    return numArtistas;
}

// Função para escrever a lista de artistas de volta para o arquivo
void escreverArtistas(Artista *lista, int numArtistas) {
    FILE *arquivo;
    arquivo = fopen("artistas.txt", "w");
    
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo artistas.txt.\n");
        return;
    }

    fprintf(arquivo, "%d\n", numArtistas);

    for (int i = 0; i < numArtistas; i++) {
        fprintf(arquivo, "%s %s %s %d\n", lista[i].nome, lista[i].genero, lista[i].local, lista[i].albums);
    }

    fclose(arquivo);
}

// Função para inserir um novo artista de forma ordenada por nome
void inserirArtista(Artista **lista, int *numArtistas, Artista novoArtista) {
    // Realloc para aumentar o tamanho da lista
    *numArtistas += 1;
    *lista = (Artista *)realloc(*lista, (*numArtistas) * sizeof(Artista));

    // Encontrar a posição correta para inserir o novo artista
    int posicao = 0;
    while (posicao < *numArtistas - 1 && strcmp(novoArtista.nome, (*lista)[posicao].nome) > 0) {
        posicao++;
    }

    // Deslocar os artistas para abrir espaço para o novo artista
    for (int i = *numArtistas - 1; i > posicao; i--) {
        (*lista)[i] = (*lista)[i - 1];
    }

    // Inserir o novo artista na posição correta
    (*lista)[posicao] = novoArtista;

    // Após inserir o novo artista, ordene a lista por nome
    qsort(*lista, *numArtistas, sizeof(Artista), compararArtistas);
}

// Função para remover um artista pelo nome
void removerArtista(Artista **lista, int *numArtistas, char nome[]) {
    int posicao = -1;

    // Encontrar a posição do artista com o nome especificado
    for (int i = 0; i < *numArtistas; i++) {
        if (strcmp(nome, (*lista)[i].nome) == 0) {
            posicao = i;
            break;
        }
    }

    if (posicao != -1) {
        // Deslocar os artistas para preencher o espaço deixado pelo artista removido
        for (int i = posicao; i < *numArtistas - 1; i++) {
            (*lista)[i] = (*lista)[i + 1];
        }

        // Realloc para diminuir o tamanho da lista
        *numArtistas -= 1;
        *lista = (Artista *)realloc(*lista, (*numArtistas) * sizeof(Artista));

        // Após remover o artista, ordene a lista por nome
        qsort(*lista, *numArtistas, sizeof(Artista), compararArtistas);
    } else {
        printf("Artista com o nome %s não encontrado.\n", nome);
    }
}

// Função para editar um artista pelo nome
void editarArtista(Artista *lista, int numArtistas, char nome[]) {
    int posicao = -1;

    // Encontrar a posição do artista com o nome especificado
    for (int i = 0; i < numArtistas; i++) {
        if (strcmp(nome, lista[i].nome) == 0) {
            posicao = i;
            break;
        }
    }

    if (posicao != -1) {
        // Pedir ao usuário para editar os dados do artista
        printf("Digite o novo nome: ");
        scanf("%s", lista[posicao].nome);
        printf("Digite o novo gênero musical: ");
        scanf("%s", lista[posicao].genero);
        printf("Digite o novo local de criação/nascimento: ");
        scanf("%s", lista[posicao].local);
        printf("Digite o novo número de álbuns: ");
        scanf("%d", &lista[posicao].albums);
        
        // Após editar o artista, ordene a lista por nome
        qsort(lista, numArtistas, sizeof(Artista), compararArtistas);
    } else {
        printf("Artista com o nome %s não encontrado.\n", nome);
    }
}

// Função para buscar um artista usando busca binária pelo nome
int buscarArtistaBinario(Artista *lista, int numArtistas, char nome[]) {
    int inicio = 0;
    int fim = numArtistas - 1;

    while (inicio <= fim) {
        int meio = (inicio + fim) / 2;
        int comparacao = strcmp(nome, lista[meio].nome);

        if (comparacao == 0) {
            return meio; // Artista encontrado
        } else if (comparacao < 0) {
            fim = meio - 1; // Procurar na metade esquerda
        } else {
            inicio = meio + 1; // Procurar na metade direita
        }
    }

    return -1; // Artista não encontrado
}

// Função para buscar um artista usando busca sequencial por um álbum
int buscarAlbumSequencial(Artista *lista, int numArtistas, int albums) {
    for (int i = 0; i < numArtistas; i++) {
        if (lista[i].albums == albums) {
            return i; // Artista encontrado
        }
    }

    return -1; // Artista não encontrado
}

int main() {
    Artista *artistas = NULL;
    int numArtistas = lerArtistas(&artistas);

    if (numArtistas == 0) {
        return 1; // Erro ao ler o arquivo
    }

    int opcao;
    do {
        printf("\nMenu:\n");
        printf("1. Inserção ordenada de um novo artista\n");
        printf("2. Remoção de um artista\n");
        printf("3. Edição de um artista\n");
        printf("4. Busca binária por um artista\n");
        printf("5. Busca sequencial por um álbum\n");
        printf("6. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: {
                Artista novoArtista;
                printf("Digite o nome do novo artista: ");
                scanf("%s", novoArtista.nome);
                printf("Digite o gênero musical: ");
                scanf("%s", novoArtista.genero);
                printf("Digite o local de criação/nascimento: ");
                scanf("%s", novoArtista.local);
                printf("Digite o número de álbuns: ");
                scanf("%d", &novoArtista.albums);
                inserirArtista(&artistas, &numArtistas, novoArtista);
                escreverArtistas(artistas, numArtistas);
                break;
            }
            case 2: {
                char nome[50];
                printf("Digite o nome do artista a ser removido: ");
                scanf("%s", nome);
                removerArtista(&artistas, &numArtistas, nome);
                escreverArtistas(artistas, numArtistas);
                break;
            }
            case 3: {
                char nome[50];
                printf("Digite o nome do artista a ser editado: ");
                scanf("%s", nome);
                editarArtista(artistas, numArtistas, nome);
                escreverArtistas(artistas, numArtistas);
                break;
            }
            case 4: {
                char nome[50];
                printf("Digite o nome do artista a ser buscado: ");
                scanf("%s", nome);
                int posicao = buscarArtistaBinario(artistas, numArtistas, nome);
                if (posicao != -1) {
                    printf("Artista encontrado:\n");
                    printf("Nome: %s\n", artistas[posicao].nome);
                    printf("Gênero musical: %s\n", artistas[posicao].genero);
                    printf("Local de criação/nascimento: %s\n", artistas[posicao].local);
                    printf("Número de álbuns: %d\n", artistas[posicao].albums);
                } else {
                    printf("Artista não encontrado.\n");
                }
                break;
            }
            case 5: {
                int albums;
                printf("Digite o número de álbuns a ser buscado: ");
                scanf("%d", &albums);
                int posicao = buscarAlbumSequencial(artistas, numArtistas, albums);
                if (posicao != -1) {
                    printf("Artista encontrado com %d álbuns:\n", albums);
                    printf("Nome: %s\n", artistas[posicao].nome);
                    printf("Gênero musical: %s\n", artistas[posicao].genero);
                    printf("Local de criação/nascimento: %s\n", artistas[posicao].local);
                    printf("Número de álbuns: %d\n", artistas[posicao].albums);
                } else {
                    printf("Nenhum artista encontrado com %d álbuns.\n", albums);
                }
                break;
            }
            case 6:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 6);

    free(artistas); // Liberar a memória alocada para a lista de artistas

    return 0;
}
